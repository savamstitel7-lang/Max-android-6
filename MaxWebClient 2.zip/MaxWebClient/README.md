# MAX Web (WebView-обёртка), Android 6+

Сборка:
1. Откройте папку проекта в Android Studio (Hedgehog или новее). Он сам создаст Gradle wrapper и скачает зависимости.
2. Build > Build APK(s). APK будет в app/build/outputs/apk/debug/.
3. Скопируйте APK на телефон и установите (разрешите установку из неизвестных источников).

Настройки: адрес и разрешённые домены в MainActivity.java (START_URL, INTERNAL_HOSTS).
